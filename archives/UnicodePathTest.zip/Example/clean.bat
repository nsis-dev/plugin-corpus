del UnicodePathTest.exe
