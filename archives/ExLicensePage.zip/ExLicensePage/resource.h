//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ExLicensePage.rc
//
#define IDD_LICENSEPAGE                 1000
#define IDC_OUTPUT                      1000
#define IDC_HEADER                      1001
#define IDC_FOOTER                      1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1001
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
